/*
Saul Rincon
MDV 2330-0
Output Assignment
07/09/2015
*/


var myJob=8;
console.log(myJob + " years");//Number Variable

var isFirefighter=false;
console.log(isFirefighter);//Boolean is obtained

var phrase="I was in the United States Army Infantry from 2003 through 2006";//String variable
console.log(phrase);

var isPoliceofficer=true;
console.log(isPoliceofficer);//Boolean

var myKids=3;
console.log(myKids);//Number variable

var yearsofWisdom=30;
console.log(yearsofWisdom + " years of it");//Number variable
